//
//  Random.h
//  Payoff_class_with_inheritance

#ifndef __Payoff_class_with_inheritance__Random__
#define __Payoff_class_with_inheritance__Random__

//Random.h

double GetOneGaussianBySummation();
double GetOneGaussianByBoxMuller();

#endif /* defined(__Payoff_class_with_inheritance__Random__) */
