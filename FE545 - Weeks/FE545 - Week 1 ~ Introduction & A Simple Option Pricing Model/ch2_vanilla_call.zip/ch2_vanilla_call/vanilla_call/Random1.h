//Random1.h

#ifndef Random1_H
#define Random1_H

double GetOneGaussianBySummation();
double GetOneGaussianByBoxMuller();

#endif
